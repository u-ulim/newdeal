import { Component } from "react";

class ClassCom3 extends Component {
    //1.상태변수
    //2. 메서드
    //3. 화면 뿌려질 내용
    render() {
        return (
            <div>
                <h2>클래스 컴포넌트</h2>
                <p>클래스 컴포넌트는 render안에 넣어야한다</p>
            </div>
        )
    }
}
export default ClassCom3;