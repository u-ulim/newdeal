function FucCom1(){
    // 1. 상태변수
    // 2. 메서드
    // 3. 화면에 뿌려질 내용
    return (
        <div>
            <h2>함수 컴포넌트만들기</h2>
            <p>일반 함수처럼 만들면된다</p>
            <p>컴포넌트 이름은 첫글자가 대문자</p>
        </div>
    )
}
export default FucCom1;