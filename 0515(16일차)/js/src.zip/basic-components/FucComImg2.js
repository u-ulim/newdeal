export default function FucComImg2(){
    return(
        <>
        <h2>함수 컴포넌트 -이미지</h2>
        <img src="./images/7.png" alt="" />
        </>
    )
}