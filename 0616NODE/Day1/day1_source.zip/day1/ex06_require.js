const obj = require('./ex06_module');
console.log(obj);

let sq = obj.square(5);
console.log(sq);
let cr = obj.circle(5);
console.log(cr.toFixed(2));
let rt = obj.reactangle(5, 8);
console.log(rt);
