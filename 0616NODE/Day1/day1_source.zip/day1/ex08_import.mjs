import { printStar } from './ex08_module.mjs';
printStar(10);
